
TITLE: 
Fox - 100% Fully Responsive One Page HTML5 Bootstrap 4 Template

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co

Website: http://freehtml5.co/
Twitter: http://twitter.com/fh5co
Facebook: http://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

animate.css
http://daneden.me/animate

Parallax
http://pixelcog.github.io/parallax.js/

Wow
https://wowjs.uk

Demo Images:
http://unsplash.com

